import torch
import cv2
import numpy as np

class Dataset(torch.utils.data.Dataset):
    def __init__(self, d_set, d_type):
        super(Dataset, self).__init__()
        self.data_set = d_set
        self.patch_h = 512
        self.patch_w = 512
        self.nb_ch_all = 3
        self.nb_ch = 3
        self.src_mean = 0
        self.trg_mean = 0
        self.color_flag = -1
        self.bit_depth = 16
        self.norm_val = (2**self.bit_depth) - 1
        self.src_ims = np.zeros((self.patch_h, self.patch_w, self.nb_ch_all))
        self.trg_ims = np.zeros((self.patch_h, self.patch_w, self.nb_ch))

    def __len__(self):
        return len(self.data_set)

    def __getitem__(self, i):
        # img_data_src_l = self.data_set[i][0].replace('/content', '/teamspace/studios/this_studio')
        img_data_src = self.data_set[i][0]
        img_data_trg = self.data_set[i][3]
        src_ims = np.zeros((self.patch_h, self.patch_w, self.nb_ch_all))
        trg_ims = np.zeros((self.patch_h, self.patch_w, self.nb_ch))

        # Read the right source image
        src_img = cv2.imread(img_data_src, self.color_flag)
        if src_img is None:
            raise ValueError(f"Failed to load image at {img_data_src}")

        # Read the target image
        trg_img = cv2.imread(img_data_trg, self.color_flag)
        if trg_img is None:
            raise ValueError(f"Failed to load image at {img_data_trg}")

        src_ims[:, :, 0:3] = ((src_img - self.src_mean) / self.norm_val).reshape((self.patch_h, self.patch_w, self.nb_ch))
        # src_ims[:, :, 3:6] = ((src_img_r - self.src_mean) / self.norm_val).reshape((self.patch_h, self.patch_w, self.nb_ch))
        trg_ims[:] = ((trg_img - self.trg_mean) / self.norm_val).reshape((self.patch_h, self.patch_w, self.nb_ch))

        return src_ims, trg_ims
