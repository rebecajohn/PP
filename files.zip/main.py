import lightning as L
import torch
import pickle
import pandas as pd
from torch.utils.data import DataLoader
from torch.autograd import Variable

# from data import *
# from utils import *
#from model import *

class DDPNet(L.LightningModule):
    def __init__(self,train_path,val_path,img_h,img_w,dim_embed,channels_no,max_len,size_patch):
        super(DDPNet,self).__init__()
        self.train_path = train_path
        self.val_path = val_path
        self.batch_size = 5
        self.train_set = pd.read_pickle(self.train_path)
        self.val_set = pd.read_pickle(self.val_path)
        self.loss_function = torch.nn.MSELoss()
        self.model = DDP_Transf(size_patch,img_h,img_w,dim_embed,channels_no,max_len) #input_channels = 6 and final output_channels=3


    def forward(self, src):
        out = self.model(src)
        return out


    def train_dataloader(self):
        return DataLoader(Dataset(self.train_set,'train'), batch_size=self.batch_size)

    def val_dataloader(self):
        return DataLoader(Dataset(self.val_set,'val'), batch_size=1)


    def configure_optimizers(self):
        optimizer = torch.optim.Adam(self.parameters(), lr = 1e-3)
        return optimizer


    def training_step(self,batch,batch_idx):
        src,trg = batch
        src = src.permute(0,3,1,2)
        src = src.float()
        score = self.forward(src)
        n = torch.squeeze(score, 1)
        trg = torch.squeeze(trg, 1)
        n = n.permute(0,2,3,1)
        trg = Variable(trg.float())
        train_loss = self.loss_function(trg,n)
        self.log('train_loss',train_loss ,on_step=False, on_epoch=True, prog_bar=True, logger=True)
        return train_loss



    def validation_step(self,batch,batch_idx):
        src,trg = batch
        src = src.permute(0,3,1,2)
        src = src.float()
        score = self.forward(src)
        n = torch.squeeze(score, 1)
        trg = torch.squeeze(trg, 1)
        n = n.permute(0,2,3,1)
        trg = Variable(trg.float())
        val_loss = self.loss_function(trg,n)
        self.log('val_loss',val_loss ,on_step=False, on_epoch=True, prog_bar=True, logger=True)
        return val_loss

if __name__ == "__main__":

    model = DDPNet(train_path='train_set_7k.pkl',val_path='val_set_888.pkl',
                   img_h=512,img_w=512,dim_embed=1024,channels_no=3,max_len=256,size_patch=32)
    trainer = L.Trainer(accelerator="gpu",max_epochs=20)
    trainer.fit(model)
    state_dict = model.state_dict()
    torch.save(state_dict, "./dddp_20_c_T_b5.ckpt")
