import torch
import torch.nn as nn

class Attention(nn.Module):
    def __init__(self, dim_embed , heads = 8, dropout = 0.1):
        super().__init__()
        self.heads = heads
        self.dim_embed = dim_embed
        self.key     =    nn.Linear(dim_embed , dim_embed)
        self.value   =    nn.Linear(dim_embed , dim_embed)
        self.query   =    nn.Linear(dim_embed , dim_embed)
        self.softmax =    nn.Softmax(dim=-1)
        self.dropout =    nn.Dropout(dropout)

    def forward(self,inp):
        key , value , query = self.key(inp) , self.value(inp),self.query(inp)
        query , key , value =  self.MultiHeads(query) ,self.MultiHeads(key) , self.MultiHeads(value)
        attention_scores = self.softmax(torch.matmul(query, key.transpose(1, 2)))
        out = torch.matmul(self.dropout(attention_scores), value)
        b, n, dim = out.size()
        batch_size = b // self.heads
        out = inp.reshape(batch_size, self.heads, n, dim)
        out = out.permute(0, 2, 1, 3)
        out = out.reshape(batch_size, n, self.dim_embed)
        return out, attention_scores

    def MultiHeads(self,inp):
        b ,n ,dim_embed  = inp.size()
        dim_head = dim_embed // self.heads
        out = inp.reshape(b,n,self.heads,dim_head)
        out = out.permute(0,2,1,3)
        out  = out.reshape(-1,n,dim_head)
        return out


class FeedForward(nn.Module):
    def __init__(self, embed_dim, dropout=0.1):
        super(FeedForward, self).__init__()
        self.embed_dim = embed_dim
        self.fc1 = nn.Linear(embed_dim, embed_dim)
        self.activation = nn.GELU()
        self.fc2 = nn.Linear(embed_dim, embed_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, inp):
        batch_size, seq_len, embed_dim = inp.size()
        out = self.dropout(self.activation(self.fc1(inp)))
        out = self.fc2(out)
        return out



class Encoder(nn.Module):
    def __init__(self,embed_dim,dropout,heads):
        super(Encoder, self).__init__()
        self.attention = Attention(embed_dim , heads, dropout)
        self.feedforward = FeedForward(embed_dim, dropout)


    def forward(self,inp):
    	b,n,d = inp.size()
    	out , _ = self.attention(inp)
    	out  = out + inp
    	res = out
    	out = self.feedforward(out)
    	out = out + res
    	return out


class Transformer(nn.Module):

    def __init__(self, embed_dim, layers, heads=8, dropout=0.1):
        super(Transformer, self).__init__()
        self.embed_dim = embed_dim
        self.trans_blocks = nn.ModuleList(
            [Encoder(embed_dim, dropout , heads) for i in range(layers)] )

    def forward(self, inp):
        for block in self.trans_blocks:
            inp = block(inp)

        return inp

def double_conv(in_c,out_c):
    conv = nn.Sequential(
        nn.Conv2d(in_c,out_c,kernel_size=3,padding=1),
        nn.ReLU(inplace=True),
        nn.Conv2d(out_c,out_c,kernel_size=3,padding=1),
        nn.ReLU(inplace=True)
        )
    return conv


class Decoder(nn.Module):

    def __init__(self,size_patch):
    	super(Decoder, self).__init__()
    	self.size_patch = size_patch
    	self.up_trans_1 = nn.ConvTranspose2d(in_channels=256,out_channels=128,kernel_size = 2 , stride = 2)
    	self.up_conv_1 = double_conv(128,64)
    	self.up_trans_2 = nn.ConvTranspose2d(in_channels=64,out_channels=32,kernel_size = 2 , stride = 2)
    	self.up_conv_2 = double_conv(32,16)
    	self.up_trans_3 = nn.ConvTranspose2d(in_channels=16,out_channels=8,kernel_size = 2 , stride = 2)
    	self.up_conv_3 = double_conv(8,4)
    	self.up_trans_4 = nn.ConvTranspose2d(in_channels=4,out_channels=3,kernel_size = 2 , stride = 2)

    def forward(self,inp):
    	b,n,dim = inp.size()                   #[1,256,1024]
    	new_dim = dim//self.size_patch
    	out = inp.reshape(b,n,new_dim,new_dim) # [1,256,32,32]
    	x = self.up_trans_1(out)               # [1,128,64,64]
    	x = self.up_conv_1(x)
    	x = self.up_trans_2(x)
    	x = self.up_conv_2(x)
    	x = self.up_trans_3(x)
    	x = self.up_conv_3(x)
    	out = self.up_trans_4(x)
    	return out



class DDP_Transf(nn.Module):
    def __init__(self,size_patch,img_h,img_w,dim_embed,channels_no,max_len):
        super(DDP_Transf,self).__init__()
        self.dim_embed = dim_embed
        self.size_patch = size_patch
        self.patches = (img_h*img_w)//(size_patch**2)
        self.patch_embed = nn.Linear(size_patch*size_patch*channels_no,dim_embed) # (9408,1024)
        self.pos_embd = nn.Parameter(torch.randn(max_len,dim_embed)) # (600,1024)
        self.transformer = Transformer(dim_embed, layers=8, heads=8,  dropout=0.1)
        self.decoder = Decoder(size_patch)



    def forward(self,inp):

        size, c, w, h = inp.size() # (1,6,512,512)
        out = inp.unfold(2, self.size_patch, self.size_patch).unfold(3, self.size_patch, self.size_patch).contiguous()
        # [1, 6, 16, 16, 32, 32]
        #  0  1   2   3   4   5
        out = out.view(size, c, -1, self.size_patch, self.size_patch) # [1, 6, 256, 32, 32]
        out = out.permute(0, 2, 3, 4, 1) # [1, 256, 32, 32, 6]
        batch_size, n, patch_size, _, channels = out.size()
        out = out.reshape(batch_size, n, -1) # [1, 256, 6144]
        p_emb = self.patch_embed(out) # [1, 256, 1024]
        pos_embd = self.pos_embd.unsqueeze(0).expand(batch_size, n, self.dim_embed)
        x = p_emb + pos_embd # [1,256,1024]
        x = self.transformer(x)  # [1,256,1024]
        #now to decoder -> inp:  [1,256,1024] ----------> [1,256,32,32]
        out = self.decoder(x)

        return out
